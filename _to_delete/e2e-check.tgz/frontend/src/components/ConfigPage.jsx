/**
 * ConfigPage.jsx — Settings and API key management
 * ==================================================
 * The Config tab. Allows the user to set API keys, choose default
 * provider/model, and edit custom prompt templates.
 *
 * SECTIONS
 * --------
 * API Keys    Input fields for NANOGPT_API_KEY, OPENROUTER_API_KEY,
 *             LOCAL_OPENAI_BASE_URL, LOCAL_MODEL, LOCAL_API_KEY.
 *             Saved via POST /api/config which writes to .env.
 *
 * Prompt Templates  Text areas for the custom system prompts used
 *                   during character and lore generation.
 *                   Saved via POST /api/config/prompts.
 *
 * PROPS
 * -----
 * t    Translation strings
 *
 * HOW TO EXTEND
 * -------------
 * - Add a new setting: add an input field, include the key in the
 *   POST /api/config body, and handle it in app.py's api_save_config.
 * - Add a new prompt template: add a textarea and a new key to
 *   prompt_templates.py's default dict.
 */

import { testSillyTavern } from "../lib/api";
import { useState, useEffect } from "react";
import AdminPanels from "./AdminPanels";

const DEFAULT_CHAR_TEMPLATE = `You are converting scraped fandom wiki data into a SillyTavern character card.

Rules:
- Do not invent facts not present in the source data.
- Keep the character canon-consistent.
- Rewrite for roleplay usefulness, not wiki style.
- Make personality behavioral, not just a list of adjectives.
- Keep first_mes short, natural, and in character.
- Do not write actions or dialogue for {{user}}.
- Output valid JSON only.

Source data:
{source_json}`;

const DEFAULT_FIELD_TEMPLATE = `You are rewriting a single field of a SillyTavern character card.

Field: {field_name}
Character: {char_name}
Custom instruction: {custom_instruction}

Source data:
{source_json}

Current card:
{card_json}

Output valid JSON only with the updated field.`;

const DEFAULT_LORE_TEMPLATE = `Generate SillyTavern lorebook entries from this wiki page.

Page: {title}
{content}

Create one entry per distinct entity. Include the main subject, each ability/skill separately, items, factions, locations, events.

Output: {"entries": [{"title":"...","entry_type":"...","keywords":["..."],"content":"..."}]}`;

export default function ConfigPage({ t = {}, showToast }) {
  const TABS = [
    { key: "character", label: t.characterGeneration || "Character Generation", templateKey: "character_generation_template", defaultVal: DEFAULT_CHAR_TEMPLATE,
      vars: ["{source_json}"], hint: "Available: {source_json} — the full scraped wiki data" },
    { key: "field", label: t.fieldRegeneration || "Field Regeneration", templateKey: "field_regeneration_template", defaultVal: DEFAULT_FIELD_TEMPLATE,
      vars: ["{field_name}", "{char_name}", "{custom_instruction}", "{source_json}", "{card_json}"],
      hint: "Available: {field_name}, {char_name}, {custom_instruction}, {source_json}, {card_json}" },
    { key: "lore", label: t.loreGeneration || "Lore Generation", templateKey: "lore_generation_template", defaultVal: DEFAULT_LORE_TEMPLATE,
      vars: ["{title}", "{content}"], hint: "Available: {title}, {content}" },
  ];
  const [activeTab, setActiveTab] = useState("character");
  const [templates, setTemplates] = useState({
    character_generation_template: "",
    field_regeneration_template: "",
    lore_generation_template: "",
    use_templates: false,
    temperature: 0.7,
    max_tokens: 4096,
    extract_max_tokens: 8000,
  });
  const [envKeys, setEnvKeys] = useState({
    NANOGPT_API_KEY: "",
    OPENROUTER_API_KEY: "",
    NANOGPT_MODEL: "",
    OPENROUTER_MODEL: "",
  });
  const [showKeys, setShowKeys] = useState({});
  const [saving, setSaving] = useState(false);
  const [savingEnv, setSavingEnv] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("/api/config/prompts").then(r => r.json()).then(data => setTemplates(data)).catch(() => {});
    fetch("/api/config/env").then(r => r.json()).then(data => setEnvKeys(data)).catch(() => {});
  }, []);

  async function saveTemplates() {
    setSaving(true); setError("");
    try {
      const res = await fetch("/api/config/prompts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(templates),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      if (showToast) showToast("Templates saved");
    } catch (e) { setError(e.message); }
    finally { setSaving(false); }
  }

  async function saveEnv() {
    setSavingEnv(true); setError("");
    try {
      const res = await fetch("/api/config/env", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(envKeys),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      if (showToast) showToast("API keys saved");
    } catch (e) { setError(e.message); }
    finally { setSavingEnv(false); }
  }

  function insertVar(v) {
    const tab = TABS.find(t => t.key === activeTab);
    if (!tab) return;
    setTemplates(prev => ({
      ...prev,
      [tab.templateKey]: (prev[tab.templateKey] || "") + v,
    }));
  }

  const tab = TABS.find(t => t.key === activeTab);

  const inputStyle = {
    padding: "10px 12px",
    border: "1px solid var(--signal-border)",
    background: "var(--signal-bg-input)",
    color: "var(--signal-text)",
    fontFamily: "inherit",
    fontSize: 13,
    boxSizing: "border-box",
    width: "100%",
  };

  const btnStyle = {
    padding: "10px 16px",
    border: "1px solid var(--signal-border)",
    background: "var(--signal-bg-btn)",
    color: "var(--signal-text)",
    cursor: "pointer",
    fontFamily: "inherit",
    fontSize: 13,
    fontWeight: 700,
    letterSpacing: "0.06em",
  };

  return (
    <div style={{ maxWidth: 900, margin: "0 auto" }}>

      {error && (
        <div style={{ color: "var(--signal-accent)", border: "1px solid var(--signal-accent)", padding: "10px 14px", marginBottom: 16, fontSize: 13 }}>
          ⊗ {error}
        </div>
      )}

      {/* ── Generation Parameters ────────────────────────── */}
      <section className="signal-panel signal-screen-panel" style={{
        border: "1px solid var(--signal-border)", background: "var(--signal-bg-panel)", padding: 20, marginBottom: 20,
      }}>
        <h2 className="signal-heading" style={{ margin: "0 0 16px", fontSize: 15 }}>Generation Parameters</h2>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
          {/* Temperature */}
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 700, letterSpacing: "0.06em" }}>
                Temperature
              </label>
              <span style={{ fontSize: 13, fontWeight: 700, color: "var(--signal-text)" }}>
                {templates.temperature?.toFixed(1) ?? "0.7"}
              </span>
            </div>
            <input
              type="range" min="0" max="1" step="0.1"
              value={templates.temperature ?? 0.7}
              onChange={e => setTemplates(p => ({ ...p, temperature: parseFloat(e.target.value) }))}
              style={{ width: "100%", accentColor: "var(--signal-text)" }}
            />
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: "var(--signal-text-dim)", marginTop: 4 }}>
              <span>0.0 — precise</span>
              <span>1.0 — creative</span>
            </div>
          </div>

          {/* Max Tokens */}
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 700, letterSpacing: "0.06em" }}>Max Tokens</label>
              <span style={{ fontSize: 13, fontWeight: 700 }}>{(templates.max_tokens ?? 4096).toLocaleString()}</span>
            </div>
            <input
              type="range" min="512" max="16384" step="256"
              value={templates.max_tokens ?? 4096}
              onChange={e => setTemplates(p => ({ ...p, max_tokens: parseInt(e.target.value) }))}
              style={{ width: "100%", accentColor: "var(--signal-text)" }}
            />
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: "var(--signal-text-dim)", marginTop: 4 }}>
              <span>512 — fast / cheap</span>
              <span>16384 — long</span>
            </div>
            <div style={{ fontSize: 10, color: "var(--signal-text-dim)", marginTop: 4 }}>
              Output limit for cards, fields and quick lore. Higher = longer output, more tokens used.
            </div>
          </div>

          {/* Deep extraction max tokens */}
          <div style={{ gridColumn: "1 / -1" }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 700, letterSpacing: "0.06em" }}>Deep Extraction Max Tokens</label>
              <span style={{ fontSize: 13, fontWeight: 700 }}>{(templates.extract_max_tokens ?? 8000).toLocaleString()}</span>
            </div>
            <input
              type="range" min="1024" max="32768" step="512"
              value={templates.extract_max_tokens ?? 8000}
              onChange={e => setTemplates(p => ({ ...p, extract_max_tokens: parseInt(e.target.value) }))}
              style={{ width: "100%", accentColor: "var(--signal-text)" }}
            />
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: "var(--signal-text-dim)", marginTop: 4 }}>
              <span>1024</span>
              <span>32768</span>
            </div>
            <div style={{ fontSize: 10, color: "var(--signal-text-dim)", marginTop: 4 }}>
              Output limit for each Deep extraction call (TEXT studio and LORE's Deep Extraction). Each entity costs about
              200 tokens, so this fits roughly {Math.floor((templates.extract_max_tokens ?? 8000) / 200)} per call. Detail calls batch 5 entities, so
              4096+ is plenty; raise it if inventory lists get cut off. Reasoning models spend part of this on thinking.
              If your model or provider caps output lower, requests may fail: lower this value.
            </div>
          </div>
        </div>
      </section>

      {/* ── Prompt Templates ─────────────────────────────── */}
      <section className="signal-panel signal-screen-panel" style={{
        border: "1px solid var(--signal-border)", background: "var(--signal-bg-panel)", padding: 20, marginBottom: 20,
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <h2 className="signal-heading" style={{ margin: 0, fontSize: 15 }}>Prompt Templates</h2>
          <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13 }}>
            <span style={{
              width: 16, height: 16, border: "1.5px solid var(--signal-border)",
              background: templates.use_templates ? "var(--signal-btn-active-bg)" : "var(--signal-bg-field)",
              display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
            }}>
              {templates.use_templates && (
                <svg width="10" height="8" viewBox="0 0 10 8" fill="none">
                  <path d="M1 3.5L3.5 6.5L9 1" stroke="var(--signal-text-inv)" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              )}
            </span>
            <input type="checkbox" checked={templates.use_templates}
              onChange={e => setTemplates(p => ({ ...p, use_templates: e.target.checked }))}
              style={{ display: "none" }} />
            Use custom templates
          </label>
        </div>

        {/* Tab bar */}
        <div style={{ display: "flex", borderBottom: "1px solid var(--signal-border)", marginBottom: 14, gap: 0 }}>
          {TABS.map(t => (
            <button key={t.key}
              className={activeTab === t.key ? "signal-btn signal-btn-active" : "signal-btn"}
              onClick={() => setActiveTab(t.key)}
              style={{ padding: "8px 14px", fontSize: 12, fontWeight: 700, border: "none",
                borderBottom: activeTab === t.key ? "2px solid var(--signal-text)" : "2px solid transparent",
                cursor: "pointer", fontFamily: "inherit", letterSpacing: "0.06em" }}>
              {t.label}
            </button>
          ))}
        </div>

        {/* Hint + variable chips */}
        <div style={{ fontSize: 11, color: "var(--signal-text-dim)", marginBottom: 8 }}>
          {tab?.hint}
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 10 }}>
          {tab?.vars.map(v => (
            <button key={v} className="signal-btn" onClick={() => insertVar(v)}
              style={{ padding: "3px 10px", fontSize: 11, fontFamily: "monospace", border: "1px solid var(--signal-border)", cursor: "pointer" }}>
              {v}
            </button>
          ))}
          <button className="signal-btn" onClick={() => setTemplates(p => ({ ...p, [tab.templateKey]: tab.defaultVal }))}
            style={{ padding: "3px 10px", fontSize: 11, border: "1px solid var(--signal-border)", cursor: "pointer", marginLeft: "auto", color: "var(--signal-text-dim)" }}>
            Reset to default
          </button>
        </div>

        <textarea
          value={templates[tab?.templateKey] ?? ""}
          onChange={e => setTemplates(p => ({ ...p, [tab.templateKey]: e.target.value }))}
          rows={18}
          placeholder={`Paste your custom ${tab?.label.toLowerCase()} prompt here...\n\nLeave empty to use the built-in default.`}
          style={{ ...inputStyle, resize: "vertical" }}
        />

        <div style={{ marginTop: 12, display: "flex", justifyContent: "flex-end" }}>
          <button className="signal-btn" onClick={saveTemplates} disabled={saving}
            style={{ ...btnStyle, opacity: saving ? 0.5 : 1, background: "var(--signal-btn-active-bg)", color: "var(--signal-text-inv)" }}>
            {saving ? (t.saving || "Saving...") : (t.saveTemplates || "Save Templates")}
          </button>
        </div>
      </section>

      {/* ── API Keys ─────────────────────────────────────── */}
      <section className="signal-panel signal-screen-panel" style={{
        border: "1px solid var(--signal-border)", background: "var(--signal-bg-panel)", padding: 20,
      }}>
        <h2 className="signal-heading" style={{ margin: "0 0 16px", fontSize: 15 }}>API Keys</h2>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
          {[
            { key: "NANOGPT_API_KEY", label: t.nanogptKey || "NanoGPT API Key", placeholder: "sk-...", isKey: true },
            { key: "OPENROUTER_API_KEY", label: t.openrouterKey || "OpenRouter API Key", placeholder: "sk-or-...", isKey: true },
            { key: "NANOGPT_MODEL", label: t.nanogptModel || "Default NanoGPT Model", placeholder: "deepseek/deepseek-v4.1-flash", isKey: false },
            { key: "OPENROUTER_MODEL", label: t.openrouterModel || "Default OpenRouter Model", placeholder: "openai/gpt-4o-mini", isKey: false },
            { key: "LOCAL_OPENAI_BASE_URL", label: "Local Server Base URL", placeholder: "http://localhost:1234/v1", isKey: false },
            { key: "LOCAL_MODEL", label: "Local Model Name", placeholder: "local-model", isKey: false },
            { key: "LOCAL_API_KEY", label: "Local API Key (if required)", placeholder: "local", isKey: true },
          ].map(({ key, label, placeholder, isKey }) => (
            <label key={key} style={{ fontSize: 12, color: "var(--signal-text-dim)", display: "flex", flexDirection: "column", gap: 4 }}>
              {label}
              <div style={{ position: "relative" }}>
                <input
                  type={isKey && !showKeys[key] ? "password" : "text"}
                  value={envKeys[key] || ""}
                  onChange={e => setEnvKeys(p => ({ ...p, [key]: e.target.value }))}
                  placeholder={placeholder}
                  style={{ ...inputStyle, paddingRight: isKey ? 40 : undefined }}
                  autoComplete="off"
                />
                {isKey && (
                  <button onClick={() => setShowKeys(p => ({ ...p, [key]: !p[key] }))}
                    aria-label={showKeys[key] ? `Hide ${label}` : `Show ${label}`}
                    style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)",
                      background: "none", border: "none", cursor: "pointer", color: "var(--signal-text-dim)", fontSize: 13 }}>
                    {showKeys[key] ? "◎" : "○"}
                  </button>
                )}
              </div>
            </label>
          ))}
        </div>

        <div style={{ fontSize: 11, color: "var(--signal-text-dim)", marginTop: 10 }}>
          Saved keys are shown masked (only the last 4 characters). Leave them as they are to keep them, or type a new key to replace one.
        </div>
        <div style={{ marginTop: 14, display: "flex", justifyContent: "flex-end" }}>
          <button className="signal-btn" onClick={saveEnv} disabled={savingEnv}
            style={{ ...btnStyle, opacity: savingEnv ? 0.5 : 1, background: "var(--signal-btn-active-bg)", color: "var(--signal-text-inv)" }}>
            {savingEnv ? (t.saving || "Saving...") : (t.saveKeys || "Save Keys")}
          </button>
        </div>
      </section>

      <SillyTavernSection envKeys={envKeys} setEnvKeys={setEnvKeys} saveEnv={saveEnv} savingEnv={savingEnv} inputStyle={inputStyle} btnStyle={btnStyle} />

      <AdminPanels showToast={showToast} t={t} />
    </div>
  );
}

/** Where "Send to SillyTavern" goes. Saved in .env with the API keys; the password comes back masked. */
function SillyTavernSection({ envKeys, setEnvKeys, saveEnv, savingEnv, inputStyle, btnStyle }) {
  const [show, setShow] = useState(false);
  const [test, setTest] = useState(null);
  const [testing, setTesting] = useState(false);
  async function runTest() {
    setTesting(true); setTest(null);
    try {
      const r = await testSillyTavern({ url: envKeys.ST_URL || "", user: envKeys.ST_USER || "", password: envKeys.ST_PASSWORD || "" });
      setTest({ ok: true, text: `Connected to SillyTavern ${r.version} at ${r.url}.` });
    } catch (e) { setTest({ ok: false, text: e.message }); }
    finally { setTesting(false); }
  }
  const field = (key, label, placeholder, secret) => (
    <label key={key} style={{ fontSize: 12, color: "var(--signal-text-dim)", display: "flex", flexDirection: "column", gap: 4 }}>
      {label}
      <div style={{ position: "relative" }}>
        <input type={secret && !show ? "password" : "text"} value={envKeys[key] || ""} placeholder={placeholder} autoComplete="off"
          aria-label={label} onChange={(e) => { setEnvKeys((p) => ({ ...p, [key]: e.target.value })); setTest(null); }}
          style={{ ...inputStyle, paddingRight: secret ? 40 : undefined }} />
        {secret && (
          <button onClick={() => setShow((v) => !v)} aria-label={show ? "Hide password" : "Show password"}
            style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)", background: "none", border: "none",
              cursor: "pointer", color: "var(--signal-text-dim)", fontSize: 13 }}>{show ? "◎" : "○"}</button>
        )}
      </div>
    </label>
  );
  return (
    <section className="signal-panel" style={{ border: "1px solid var(--signal-border)", background: "var(--signal-bg-panel)", padding: 20, marginTop: 20 }}>
      <h2 className="signal-heading" style={{ margin: "0 0 6px", fontSize: 15 }}>SillyTavern</h2>
      <div style={{ fontSize: 11, color: "var(--signal-text-dim)", marginBottom: 14, lineHeight: 1.5 }}>
        For the SEND TO SILLYTAVERN buttons: cards, lorebooks and Quick Reply sets go straight into a running SillyTavern.
        User name and password are only needed if SillyTavern has basic auth turned on (basicAuthMode in its config.yaml).
        If SillyTavern runs on another computer, that computer's whitelist must allow this one.
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 14 }}>
        {field("ST_URL", "SillyTavern address", "http://127.0.0.1:8000")}
        {field("ST_USER", "User name (basic auth)", "leave empty if not used")}
        {field("ST_PASSWORD", "Password (basic auth)", "", true)}
      </div>
      {test && <div role="status" style={{ fontSize: 12, marginTop: 10, color: test.ok ? "var(--signal-text)" : "var(--signal-accent)" }}>{test.ok ? "✓" : "⊗"} {test.text}</div>}
      <div style={{ marginTop: 14, display: "flex", gap: 8, justifyContent: "flex-end" }}>
        <button className="signal-btn" onClick={runTest} disabled={testing} style={{ ...btnStyle, opacity: testing ? 0.5 : 1 }}>
          {testing ? "TESTING…" : "TEST CONNECTION"}
        </button>
        <button className="signal-btn" onClick={saveEnv} disabled={savingEnv}
          style={{ ...btnStyle, opacity: savingEnv ? 0.5 : 1, background: "var(--signal-btn-active-bg)", color: "var(--signal-text-inv)" }}>
          {savingEnv ? "SAVING…" : "SAVE"}
        </button>
      </div>
    </section>
  );
}
