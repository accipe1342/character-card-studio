"""
generator.py - AI card and lore generation
===========================================
Sends prompts to the configured AI provider and parses the response
into structured data. Supports three providers: NanoGPT, OpenRouter,
and any OpenAI-compatible local server (LM Studio, Ollama, KoboldCPP).

MAIN ENTRY POINTS
-----------------
generate_full_card(source, provider, model, use_config=True) -> dict
    Takes a normalised source dict from scraper.py and generates a
    complete SillyTavern V2 character card. Returns a dict with keys:
    name, description, personality, scenario, first_mes, mes_example,
    tags, structured_profile.

regenerate_single_field(source, card, field_name, provider, model, ...) -> dict
    Regenerates a single field of an existing card in context of the
    full card. Returns the new field value as a dict.

generate_lore_entry(source, provider, model, ...) -> dict
    Generates a single lore entry from a source with valid/reason
    validation. Returns dict with valid, reason, entry keys.

PROVIDER ROUTING
----------------
_request(provider, model, system, prompt) -> dict
    Internal function. Takes separate system and user messages.
    All generation functions call this.

    Provider strings:  "nanogpt" | "openrouter" | "local"

HOW TO EXTEND
-------------
- Add a new provider: add a branch in _build_request().
- Change the card format: edit CHARACTER_CARD_DEFINITION and the
  prompt in generate_full_card().
- Add a new structured field: add to DEFAULT_STRUCTURED_PROFILE in
  database.py AND add to the prompt in generate_full_card().
- Adjust retry/timeout: edit _RETRY_MAX_ATTEMPTS and TIMEOUT_SECONDS.
"""

from pathlib import Path
import json
import os
import re
import threading
import time
from typing import Any, Dict, Optional
from prompt_templates import get_prompt_templates
import requests
from dotenv import load_dotenv
from requests.exceptions import Timeout

load_dotenv()

_RESET = "\033[0m"; _BOLD = "\033[1m"
_CYAN = "\033[36m"; _GREEN = "\033[32m"
_YELLOW = "\033[33m"; _DIM = "\033[2m"
def _log_info(m):  print(f"{_CYAN}[.]{_RESET} {m}")
def _log_ok(m):    print(f"{_GREEN}[OK]{_RESET} {_BOLD}{m}{_RESET}")
def _log_warn(m):  print(f"{_YELLOW}[!]{_RESET} {m}")
def _log_dim(m):   print(f"{_DIM}{m}{_RESET}")

NANOGPT_URL      = "https://nano-gpt.com/api/v1/chat/completions"
OPENROUTER_URL   = "https://openrouter.ai/api/v1/chat/completions"
# Defaults only. The values saved in Config (.env) are read at call time, so changing them
# in the UI applies immediately, no restart needed.
NANOGPT_MODEL    = "deepseek/deepseek-v4.1-flash"   # fast, non-thinking: generation makes many calls
OPENROUTER_MODEL = "z-ai/glm-4.7"
OPENROUTER_ENABLE_REASONING = True
TEMPERATURE      = 0.7
LOCAL_BASE_URL   = "http://localhost:1234/v1"
LOCAL_MODEL      = ""
LOCAL_API_KEY    = "local"


def _env(name, default):
    return os.getenv(name) or default
TIMEOUT_SECONDS  = 180

_RETRY_MAX_ATTEMPTS   = 3
_RETRY_BACKOFF_SECONDS = [2, 4]
_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}

REQUIRED_KEYS = {
    "name", "structured_profile", "description",
    "personality", "scenario", "first_mes", "mes_example", "tags",
}


# -------------------------------------------------------------------------------
# DEFINITIONS  (injected as system context)
# -------------------------------------------------------------------------------

LOREBOOK_DEFINITION = """
### WORLDINFO (LOREBOOK) DEFINITION

A Lorebook is a layered collection of entries that give an AI consistent,
contextual information about a fictional world during roleplay or storytelling.
Entries are organized into four layers, each with a specific purpose.

---

LAYER SYSTEM:

Layer 1 — WORLD RULES (entry_type: "concept")
  Core facts, power systems, or universal lore the AI must never violate.
  Examples: magic systems, political structures, universal laws of the world.

Layer 2 — FACTION ANCHORS (entry_type: "faction")
  One entry per organization, army, group, side, or institution.
  Must name every key member in the content to enable chaining.
  Examples: the Blacks, the Greens, the Taimanin, the Dark Elf kingdom,
  a school or academy, a criminal network, a corporation.

Layer 3 — CHARACTERS (entry_type: "character")
  One entry per named individual.
  Cover: appearance, personality in prose, behavior, key relationships, role.
  Name all relationships and factions in the content to enable chaining.

Layer 4 — DETAIL ENTRIES (entry_type: "place" | "item" | "event" | "ability")
  One entry per named location, item, technique, or significant event.
  Location entries must name NPCs and items present within them.
  Event entries cover named historical or story moments.
  Ability entries cover named powers, techniques, spells, or skills.

---

ENTRY FIELDS:
- `title`: Short specific name (e.g. "Mysaria", "The White Worm Network", "Dragonstone")
- `entry_type`: character | ability | item | faction | place | event | concept
- `keywords`: 2-6 trigger words. Always include the name + aliases + possessives.
  Good: ["Mysaria", "White Worm", "Mysaria's", "the spymistress"]
  Bad: ["character", "important", "the woman", "spy"]
  Faction anchors must include shorthand: ["the Blacks", "Blacks", "Black faction"]
  Never use generic descriptors — only names and titles someone would actually say.
- `summary`: 1-2 sentence overview for browsing. Not injected into context.
- `content`: 150-400 words. Plain encyclopedic prose, written in-universe.
  Lead with the single most important fact about this entry.
  Layer 2 (factions): name every key member in the content.
  Layer 3 (characters): name all factions and key relationships.
  Layer 4 (locations): name NPCs and items present.
  Never use bullet points. Never summarize gameplay mechanics.

---

GENERATION RULES:
Extract EVERY distinct named entity from the source as its own entry.
Aim for 10-20 entries per page minimum. Rich pages should yield more.

For each source section, extract:
- Named characters → Layer 3 entry each
- Named factions, armies, organizations, schools, institutions → Layer 2 entry each
- Named cities, towns, regions, kingdoms, realms → Layer 4 place entry each
- Named buildings, landmarks, districts, facilities → Layer 4 place entry each
- Named abilities, techniques, powers, spells → Layer 4 ability entry each
- Named items, weapons, artifacts → Layer 4 item entry each
- Named events, battles, incidents → Layer 4 event entry each
- Core world rules or power systems → Layer 1 concept entry each
- Key relationships that define the character → Layer 4 concept entry

Priority chain for content:
  Level 1 — Named sections (Personality, Appearance, Abilities, Quotes, Background)
  Level 2 — Structured source sections (history, biography, raw_sections)
  Level 3 — story_sections and uncategorized_sections — scan for ALL named
    entities even if buried in episode summaries, season recaps, or raw narrative.
    Each named character, location, faction, or event found becomes its own entry.

Additional rules:
- If a Quotes section exists: use quotes in character content to anchor voice.
- If infobox has Likes/Dislikes: include them in the character entry content.
- If episode or season summaries exist: mine every paragraph for named entities.
- For relationships that define the character (e.g. Mysaria and Daemon):
  create a concept or event entry capturing the dynamic.

---

EXAMPLES:

Layer 2 — Faction:
{
  "title": "The Blacks",
  "entry_type": "faction",
  "keywords": ["the Blacks", "Blacks", "Black faction", "Rhaenyra's faction"],
  "summary": "The faction supporting Rhaenyra Targaryen's claim to the Iron Throne.",
  "content": "The Blacks are the faction loyal to Queen Rhaenyra Targaryen in the Targaryen civil war known as the Dance of Dragons. Based at Dragonstone, their key members include Rhaenyra herself, Prince Daemon Targaryen, Mysaria the White Worm, Ser Erryk Cargyll, and Addam of Hull. They control the Velaryon fleet and several dragons but lack a standing army on the continent. Their primary opponents are the Greens, led by King Aegon II Targaryen from King's Landing."
}

Layer 3 — Character:
{
  "title": "Mysaria",
  "entry_type": "character",
  "keywords": ["Mysaria", "White Worm", "Mysaria's", "the spymistress", "Lady Mysaria"],
  "summary": "Former paramour of Daemon Targaryen, now spymistress for Queen Rhaenyra.",
  "content": "Mysaria is a survivor from Yi Ti who rose from slavery and prostitution to become the most dangerous information broker in King's Landing under the alias the White Worm. Strong-willed and pragmatic, she does not act from loyalty but from calculated self-interest. Her relationship with Daemon Targaryen is defined by mutual use: he exploited her, she profited from him. Her alliance with Rhaenyra Targaryen is warmer — Rhaenyra showed her genuine mercy, which Mysaria repaid by saving her life and lending her spy network to the Black cause. She is fiercely opposed to the exploitation of children. Her network operates through trusted intermediaries including Elinda Massey and Talya."
}

Layer 4 — Place:
{
  "title": "King's Landing",
  "entry_type": "place",
  "keywords": ["King's Landing", "the capital", "the city"],
  "summary": "Capital city of the Seven Kingdoms and seat of the Iron Throne.",
  "content": "King's Landing is the largest city in Westeros and seat of the Iron Throne, controlled by the Greens during the Dance of Dragons. Its districts include Flea Bottom, the city's poorest quarter where Mysaria operated her spy network and dismantled child exploitation rings. Key locations within the city include the Red Keep, the Grand Sept, and the pot-shops and manse where Mysaria conducted her intelligence operations. The city's smallfolk are a significant political force, as Mysaria reminded both Otto Hightower and Rhaenyra Targaryen."
}

Layer 4 — Event:
{
  "title": "The Dance of Dragons",
  "entry_type": "event",
  "keywords": ["Dance of Dragons", "the Dance", "Targaryen civil war"],
  "summary": "The Targaryen civil war fought between the Blacks and the Greens.",
  "content": "The Dance of Dragons is the name given to the civil war that erupted within House Targaryen over the succession to the Iron Throne following the death of King Viserys I. The conflict pits Queen Rhaenyra Targaryen and her supporters, known as the Blacks, against King Aegon II Targaryen and his supporters, known as the Greens. The war is fought across Westeros and involves dragon combat, political intrigue, and the manipulation of the smallfolk. Mysaria serves as a key intelligence operative for the Black cause during this conflict."
}

---

VALIDATION:
Set `valid: false` for:
- List, index, category, or disambiguation pages
- Redirect pages or stubs under ~100 words
- Real-world meta pages (voice actors, developers, release dates)
- Pages that only mention the subject in passing
- Pages with no usable lore content (copyright notices, empty fields, etc.)

When setting valid: false, keep the reason SHORT — one sentence max.
Example: "Category page with no character content."
Example: "Page is a copyright notice with no lore data."
Example: "Stub page under 100 words."
""".strip()


CHARACTER_CARD_DEFINITION = """
### CHARACTER CARD DEFINITION

A Character Card defines a fictional character for AI roleplay. Each field
serves a specific purpose - fill them with that purpose in mind.

**`name`**
The character's primary identifier. Use their most commonly known name.
Example: "Seraph Voss" not "Commander Seraph Voss of the Ashguard (formerly known as...)"

**`description`**
A snapshot combining appearance, personality, and key traits. Structure:
- Appearance: physical traits (silver-streaked hair, burn scar across jaw, worn leather pauldron)
- Personality: core demeanor (calculating, dry-humored, intensely private)
- Mannerisms: unique habits that make them feel real (drums fingers when thinking, never sits with her back to a door)
Keep it vivid and concise. Prioritise traits that affect roleplay.

**`personality`**
How the character thinks and behaves - the core of who they are. Include:
- Core traits (e.g. "commands loyalty through fear and respect in equal measure")
- Motivations and goals (reclaim her title, expose the Council's corruption)
- Flaws and contradictions (ruthless in strategy, but can't abandon soldiers she's bonded with)
- How they treat {{user}} (wary at first, tests loyalty before showing any warmth)
Write in third person, behaviorally. Avoid adjective lists.

**`scenario`**
Sets the stage for the interaction. Include:
- Where and when the scene takes place (the war tent outside Ashfield Gate, eve of the siege)
- The character's current situation or goal (needs information {{user}} carries)
- The relationship or dynamic with {{user}} (uneasy alliance, neither fully trusts the other)
Ground it in canon. Keep it immersive, not a plot summary.

**`first_mes`**
The character's opening line. It must:
- Establish their voice and speech style immediately
- Include subtle action or body language (*doesn't look up from the map*)
- End with a hook that invites the user to respond
Never use a passive opening like "Hello, how can I help you?"
Example: *Seraph doesn't look up from the map pinned across the table.* "You're late. Sit down and tell me what you saw at the eastern pass — and leave out the parts you think I want to hear."

**`mes_example`**
3-6 example exchanges showing the character's range. Format:
<START>
{{char}}: [in-character line with action + dialogue]

Show different moods: commanding, sardonic, briefly vulnerable, cold.
Never write {{user}} lines. Each block starts with <START>.

**`tags`**
A flat list of at least 10 short descriptive tags. Draw from ALL available source data:
- Franchise/series name (e.g. the game, book or show title)
- Character type (e.g. "spy", "dark elf", "queen", "mercenary")
- Personality descriptors (e.g. "cunning", "stoic", "seductive")
- Setting/world (e.g. "fantasy", "post-apocalyptic", "medieval")
- Relationship role (e.g. "rival", "anti-hero", "love interest")
- Notable traits or abilities (e.g. "necromancer", "swordswoman", "spymistress")
- Genre descriptors (e.g. "action", "romance", "political intrigue")
- Physical traits worth tagging (e.g. "dark elf", "black hair", "tall")
Aim for 10-20 tags. Use lowercase, no hashtags. Be specific over generic.
Bad: ["character", "female", "powerful"] Good: ["dark elf queen", "necromancer", "cunning", "seductive", "anti-villain"]

**`structured_profile`**
Factual fields extracted directly from source. Only fill fields with
clear source support - leave blank rather than invent.
List fields (appearance, clothing, etc.) use short, specific phrases.
""".strip()


# -------------------------------------------------------------------------------
# JSON helpers
# -------------------------------------------------------------------------------

def _strip_code_fences(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    return text.strip()


# What the last model call in THIS thread cost, so a caller can report it per answer (Flask gives each request
# its own thread, so one call's numbers never land on another's).
_LAST_CALL = threading.local()


def last_call_usage():
    """{provider, model, prompt_tokens, completion_tokens, seconds} for the last call made on this thread."""
    return getattr(_LAST_CALL, "usage", None)


class NotJSONError(ValueError):
    """The model answered, but not with a JSON object. `raw` holds the whole answer (the message only a part)."""

    def __init__(self, raw):
        self.raw = raw or ""
        super().__init__(f"Model response could not be parsed as JSON even after repair attempt. Raw: {self.raw[:1200]}")


def _as_object(parsed):
    """A parsed JSON value as the object callers expect. A top-level list of objects (models do this for 'list of
    entries/entities') is wrapped under the usual keys; anything else is not an object -> None."""
    if isinstance(parsed, dict):
        return parsed
    if isinstance(parsed, list) and parsed and all(isinstance(x, dict) for x in parsed):
        return {"entries": parsed, "entities": parsed, "items": parsed}
    return None


def _extract_json_object(text: str) -> Dict[str, Any]:
    # thinking models often write their reasoning first; the answer is what follows it
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE).strip()
    text = _strip_code_fences(text)

    try:
        obj = _as_object(json.loads(text))
        if obj is not None:
            return obj
    except json.JSONDecodeError:
        pass

    match = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if match:
        candidate = match.group(0)
        try:
            obj = _as_object(json.loads(candidate))
            if obj is not None:
                return obj
        except json.JSONDecodeError:
            pass
        try:
            from json_repair import repair_json
            repaired = repair_json(candidate, return_objects=True)
            if isinstance(repaired, dict):
                _log_warn("JSON repaired - model returned malformed response")
                return repaired
        except Exception as repair_err:
            _log_dim(f"  repair attempt failed: {repair_err}")

    try:
        from json_repair import repair_json
        repaired = repair_json(text, return_objects=True)
        if isinstance(repaired, dict):
            _log_warn("JSON repaired (full text fallback)")
            return repaired
    except Exception:
        pass

    raise NotJSONError(text)


# ── reading model output that doesn't follow the requested shape ──────────────
# Models routinely send a string where a list was asked for, a list where text was asked for, numbers as "7/10",
# or plain prose instead of JSON. These helpers turn those into what the code expects instead of crashing or
# storing "['a', 'b']".

def text_of(value: Any, sep: str = " ") -> str:
    """Any JSON value as plain text: lists are joined, objects become 'key: value' pairs, None is ''."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, bool):
        return ""
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, list):
        return sep.join(t for t in (text_of(v, sep) for v in value) if t)
    if isinstance(value, dict):
        return "; ".join(f"{k}: {text_of(v, ', ')}" for k, v in value.items() if text_of(v, ", "))
    return str(value).strip()


def list_of(value: Any, split: bool = True, limit: int = 50) -> list:
    """Any JSON value as a list of non-empty strings. A plain string becomes one item, or with split=True is
    split on commas, semicolons and new lines ("Mar, Mara" -> ["Mar", "Mara"], never letter by letter)."""
    if value is None or isinstance(value, bool):
        return []
    if isinstance(value, str):
        v = value.strip()
        if v.startswith("[") and v.endswith("]"):
            try:
                return list_of(json.loads(v), split, limit)
            except (json.JSONDecodeError, ValueError):
                pass
        parts = re.split(r"\s*[,;\n]\s*", v) if split else [v]
        return [p for p in (_unwrap_quotes(x) for x in parts) if p][:limit]
    if isinstance(value, dict):
        value = list(value.values()) if all(isinstance(v, str) for v in value.values()) else [value]
    if isinstance(value, list):
        out = []
        for v in value:
            t = text_of(v) if not isinstance(v, dict) else text_of(v.get("name") or v.get("text") or v.get("value") or v)
            if t:
                out.append(t)
        return out[:limit]
    return [text_of(value)] if text_of(value) else []


def _unwrap_quotes(t):
    """'"tea"' -> 'tea', but '"Again?" she sighs.' stays as it is (only quotes around the WHOLE item go)."""
    t = t.strip()
    while len(t) > 1 and t[0] == t[-1] and t[0] in "\"'" and t.count(t[0]) == 2:
        t = t[1:-1].strip()
    return t


def number_of(value: Any):
    """A score as a number: 7, "7", "7/10", "7.5 out of 10" -> 7 / 7.5; anything else -> None."""
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return value
    m = re.search(r"-?\d+(?:\.\d+)?", str(value or ""))
    return float(m.group(0)) if m else None


REPLY_KEYS = ("reply", "response", "answer", "text", "content", "message", "output", "result")


def request_text(provider: str, model: str, prompt: str, system: Optional[str], key: str,
                 max_tokens: Optional[int] = None, call=None) -> Dict[str, Any]:
    """_request for calls whose answer is mainly ONE piece of text under `key` (a greeting, a rewrite, a reply).
    Copes with models that ignore the JSON instruction: plain prose comes back as {key: prose, "plain": True},
    and the text under a different key ("response", "content", ...) is moved to `key`."""
    try:
        res = (call or _request)(provider, model, prompt, system=system, max_tokens=max_tokens)
    except NotJSONError as e:                   # the model answered in prose: that prose is the answer
        raw = _strip_code_fences(e.raw).strip()
        try:
            as_json = json.loads(raw)               # a bare JSON string ("Hello.") or a list of lines
            if isinstance(as_json, (str, list)) and text_of(as_json, "\n"):
                raw = text_of(as_json, "\n")
        except (json.JSONDecodeError, ValueError):
            pass
        if not raw:
            raise
        return {key: raw, "plain": True}
    if not text_of(res.get(key)):
        alt = next((res[k] for k in REPLY_KEYS if k != key and text_of(res.get(k))), None)
        if alt is not None:
            res = {**res, key: alt}
    return res


def _ensure_list(value: Any) -> list:
    """Normalise a value to a list - handles JSON strings, None, scalars."""
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return parsed
        except (json.JSONDecodeError, ValueError):
            pass
        return [value] if value.strip() else []
    return []


def load_runtime_config():
    try:
        with open(Path(__file__).resolve().parent / "config" / "settings.json", "r") as f:
            return json.load(f)
    except Exception:
        return {"use_templates": False, "temperature": 0.7, "max_tokens": 4096}


# -------------------------------------------------------------------------------
# Provider layer  (now accepts separate system + user messages)
# -------------------------------------------------------------------------------

def get_nanogpt_key() -> str:
    return os.getenv("NANOGPT_API_KEY", "")


def get_openrouter_key() -> str:
    return os.getenv("OPENROUTER_API_KEY", "")


def _build_messages(system: str, user: str) -> list:
    """Build the messages array from separate system and user strings."""
    return [
        {"role": "system", "content": system.strip()},
        {"role": "user",   "content": user.strip()},
    ]


def _build_request(
    provider: str, model: str, system: str, user: str,
    temperature: float = TEMPERATURE, max_tokens: int = 4096
):
    """Return (url, headers, payload) for the given provider."""
    messages = _build_messages(system, user)

    if provider == "nanogpt":
        api_key = get_nanogpt_key()
        if not api_key:
            raise ValueError("Missing NANOGPT_API_KEY environment variable.")
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": model or _env("NANOGPT_MODEL", NANOGPT_MODEL),
            "messages": messages,
            "temperature": temperature,
            "stream": False,
            "max_tokens": max_tokens,
        }
        return NANOGPT_URL, headers, payload

    elif provider == "openrouter":
        api_key = get_openrouter_key()
        if not api_key:
            raise ValueError("Missing OPENROUTER_API_KEY environment variable.")
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "http://localhost",
            "X-Title": "Character Card Studio",
        }
        payload = {
            "model": model or _env("OPENROUTER_MODEL", OPENROUTER_MODEL),
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if OPENROUTER_ENABLE_REASONING:
            payload["reasoning"] = {"enabled": True}
        return OPENROUTER_URL, headers, payload

    elif provider == "local":
        base_url = _env("LOCAL_OPENAI_BASE_URL", LOCAL_BASE_URL).rstrip("/")
        headers = {
            "Authorization": f"Bearer {_env('LOCAL_API_KEY', LOCAL_API_KEY) or 'local'}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": model or _env("LOCAL_MODEL", LOCAL_MODEL) or "local-model",
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        return f"{base_url}/chat/completions", headers, payload

    else:
        _log_warn(f"Unknown provider '{provider}', treating as local OpenAI-compatible")
        base_url = _env("LOCAL_OPENAI_BASE_URL", LOCAL_BASE_URL).rstrip("/")
        headers = {
            "Authorization": f"Bearer {_env('LOCAL_API_KEY', LOCAL_API_KEY) or 'local'}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": model or _env("LOCAL_MODEL", LOCAL_MODEL) or provider,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        return f"{base_url}/chat/completions", headers, payload


def _request(
    provider: str,
    model: str,
    prompt: str,
    system: Optional[str] = None,
    max_tokens: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Send a request to the provider. Accepts either:
      - _request(provider, model, prompt)              - legacy single-message
      - _request(provider, model, prompt, system=...)  - system + user split
    """
    import traceback

    provider = (provider or "").strip().lower()
    _log_info(f"Request  ->  {provider}/{model or '(default)'}")

    # If no explicit system message, use the old single-message style
    effective_system = system if system is not None else "Return only valid JSON. No markdown fences."

    # Read temperature and max_tokens from settings.json
    cfg = load_runtime_config()
    cfg_temperature = float(cfg.get("temperature", TEMPERATURE))
    cfg_max_tokens = int(max_tokens or cfg.get("max_tokens", 4096))

    url, headers, payload = _build_request(
        provider, model, effective_system, prompt,
        temperature=cfg_temperature, max_tokens=cfg_max_tokens,
    )

    last_exception: Exception = RuntimeError("No attempts made")
    retry_after = None   # seconds the provider asked us to wait (HTTP 429 Retry-After)

    for attempt in range(1, _RETRY_MAX_ATTEMPTS + 1):
        if attempt > 1:
            wait = _RETRY_BACKOFF_SECONDS[attempt - 2]
            if retry_after is not None:
                wait = max(wait, min(retry_after, 60))
            _log_warn(f"attempt {attempt}/{_RETRY_MAX_ATTEMPTS} - waiting {wait}s")
            time.sleep(wait)
            retry_after = None

        try:
            _log_dim(f"  -> sending (attempt {attempt})")
            t0 = time.time()
            response = requests.post(url, headers=headers, json=payload, timeout=TIMEOUT_SECONDS)
            _log_dim(f"  <- {response.status_code}")

            if response.status_code in _RETRYABLE_STATUS_CODES:
                msg = f"HTTP {response.status_code} from {provider} (attempt {attempt})"
                if response.status_code == 429:
                    msg += " - rate limited; lower 'Chunks at once' if this keeps happening"
                    retry_after = _parse_retry_after(response.headers.get("Retry-After"))
                    if retry_after is None:
                        retry_after = 10 * attempt     # no hint: back off harder than for other errors
                _log_warn(msg)
                last_exception = RuntimeError(msg)
                continue

            response.raise_for_status()

            data = response.json()
            choice = (data.get("choices") or [{}])[0] or {}
            msg_obj = choice.get("message") or {}
            content = msg_obj.get("content")
            if isinstance(content, list):      # some providers answer in content parts
                content = "".join(part.get("text", "") for part in content if isinstance(part, dict))
            content = content or ""
            if not content.strip():
                # a thinking model can spend its whole answer in the reasoning field and leave content empty
                content = text_of(msg_obj.get("reasoning_content") or msg_obj.get("reasoning") or "", "\n")
            if not content.strip():
                why = {"length": "it hit the token limit before writing an answer - raise max_tokens in CONFIG, "
                                 "or pick a model that does not think for as long",
                       "content_filter": "the provider filtered the answer"}.get(choice.get("finish_reason") or "",
                       "it answered with nothing at all")
                raise RuntimeError(f"{provider}/{payload.get('model', model or '')} returned an empty reply: {why}.")
            usage = data.get("usage") or {}
            _LAST_CALL.usage = {"provider": provider, "model": payload.get("model", model or ""),
                                "finish_reason": choice.get("finish_reason") or "",
                                "prompt_tokens": int(usage.get("prompt_tokens") or 0),
                                "completion_tokens": int(usage.get("completion_tokens") or 0),
                                "seconds": round(time.time() - t0, 2)}
            try:
                from database import record_usage
                record_usage(provider, payload.get("model", model or ""), usage.get("prompt_tokens", 0),
                             usage.get("completion_tokens", 0), time.time() - t0)
            except Exception:
                pass
            return _extract_json_object(content)

        except Timeout:
            msg = (
                f"{provider} request timed out on attempt {attempt}. "
                "Try a faster model, or a smaller prompt."
            )
            _log_warn(msg)
            last_exception = RuntimeError(msg)

        except (ValueError, RuntimeError):
            raise

        except Exception as exc:
            traceback.print_exc()
            last_exception = exc

    raise RuntimeError(
        f"{provider} request failed after {_RETRY_MAX_ATTEMPTS} attempts. "
        f"Last error: {last_exception}"
    ) from last_exception


def _parse_retry_after(value):
    """Retry-After is seconds or an HTTP date; return seconds or None."""
    if not value:
        return None
    try:
        return max(0, int(float(value)))
    except ValueError:
        try:
            from email.utils import parsedate_to_datetime
            import datetime as _dt
            return max(0, int((parsedate_to_datetime(value) - _dt.datetime.now(_dt.timezone.utc)).total_seconds()))
        except Exception:
            return None


# -------------------------------------------------------------------------------
# Character card generation
# -------------------------------------------------------------------------------

def generate_full_card(
    source: Dict[str, Any], provider: str, model: str, options: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Generate a complete SillyTavern V2 character card from a scraped source.
    Uses system/user message split: definitions in system, source in user.
    """
    # Trim source to key fields - avoid sending huge normalized blobs
    normalized = source.get("normalized", {})
    # Pull ability-related uncategorized sections (e.g. "Season Two", "Fighting Style")
    uncategorized = normalized.get("uncategorized_sections") or source.get("uncategorized_sections", {})
    ability_keywords = {"attack", "moveset", "move", "skill", "power", "ability", "technique",
                        "magic", "spell", "art", "fighting", "combat", "gameplay", "weapon"}
    extra_abilities_card = {
        k: v[:3] for k, v in (uncategorized.items() if isinstance(uncategorized, dict) else {}.items())
        if any(kw in k.lower() for kw in ability_keywords)
    }

    compact_source = {
        "title":             normalized.get("title", ""),
        "summary":           normalized.get("summary", ""),
        "franchise":         normalized.get("franchise", ""),
        "normalized_infobox": normalized.get("normalized_infobox", {}),
        "appearance_list":   normalized.get("appearance_list", [])[:15],
        "personality_traits": normalized.get("personality_traits", [])[:15],
        "abilities_list":    normalized.get("abilities_list", [])[:15],
        "history_list":      normalized.get("history_list", [])[:12],
        "relationships":     normalized.get("relationships", [])[:10],
        "speech_patterns":   normalized.get("speech_patterns", [])[:8],
    }
    if extra_abilities_card:
        compact_source["extra_ability_sections"] = extra_abilities_card

    # If personality/appearance/abilities are sparse, pull from uncategorized sections
    # This handles wikis where all content is in event/game-named sections (some game wikis do this)
    personality_sparse = not normalized.get("personality_traits") and not normalized.get("personality")
    appearance_sparse = len(normalized.get("appearance_list", [])) <= 2
    if personality_sparse or appearance_sparse:
        # Include a trimmed selection of uncategorized sections for context
        uncategorized_trimmed = {}
        char_limit = 0
        for section_name, paragraphs in (uncategorized.items() if isinstance(uncategorized, dict) else {}.items()):
            if section_name.lower() in {"bibliography", "sources", "references", "notes", "gallery"}:
                continue
            # Take first 2 paragraphs per section, cap total at ~3000 chars
            trimmed = paragraphs[:2]
            for p in trimmed:
                char_limit += len(p)
            if char_limit > 3000:
                break
            uncategorized_trimmed[section_name] = trimmed
        if uncategorized_trimmed:
            compact_source["story_sections"] = uncategorized_trimmed
    source_json = json.dumps(compact_source, ensure_ascii=False, indent=2)

    templates = get_prompt_templates()
    config = load_runtime_config()
    use_config = config.get("use_templates", False)
    template_text = templates.get("character_generation_template", "").strip()

    options = options or {}
    deep = bool(options.get("deep"))
    if deep:
        # richer source for the bible pass: every normalized section, trimmed to a sane size
        rich = {k: v for k, v in normalized.items() if k not in ("raw_html",) and v}
        rich["raw_sections"] = source.get("raw_sections") or {}
        rich_json = json.dumps(rich, ensure_ascii=False, indent=1)[:18000]
        _progress(options, "Reading the source into a character bible (1/3)...")
        bible = _request(provider, model, f"SOURCE DATA:\n{rich_json}",
                         system=BIBLE_SYSTEM + _fic_note(source) + _story_point_note(options))
        source_json = ("CHARACTER BIBLE (primary, already checked against the source):\n"
                       + json.dumps(bible, ensure_ascii=False, indent=1)
                       + "\n\nCOMPACT SOURCE (reference):\n" + source_json)
        _progress(options, "Writing the card from the bible (2/3)...")

    templates = get_prompt_templates()
    config = load_runtime_config()
    use_config = config.get("use_templates", False)
    template_text = templates.get("character_generation_template", "").strip()

    system = card_system_prompt(source, options)

    # User message: source data (or custom template)
    if use_config and template_text and not deep:
        try:
            user = template_text.format(source_json=source_json)
        except Exception as e:
            _log_warn(f"Template error, falling back to default: {e}")
            user = f"SOURCE DATA:\n{source_json}"
    else:
        user = f"SOURCE DATA:\n{source_json}"

    result = _request(provider, model, user, system=system)
    _log_dim(f"  card keys: {list(result.keys())}")

    if deep:
        _progress(options, "Checking the card against the bible (3/3)...")
        try:
            check = _request(provider, model,
                             "CHARACTER BIBLE:\n" + json.dumps(bible, ensure_ascii=False, indent=1)
                             + "\n\nCARD:\n" + json.dumps(result, ensure_ascii=False, indent=1),
                             system=CHECK_SYSTEM)
            applied = apply_card_fixes(result, check.get("fixes") or {})
            result["_check_issues"] = [str(x) for x in (check.get("issues") or [])][:12]
            _log_dim(f"  check pass: {applied} fix(es)")
        except Exception as e:
            _log_warn(f"check pass failed, keeping the card as written: {e}")

    for key in REQUIRED_KEYS:
        if key == "tags":
            result.setdefault("tags", [])
        elif key == "structured_profile":
            result.setdefault("structured_profile", {})
        else:
            result.setdefault(key, "")

    result, warnings = validate_card(result, options)
    result["_warnings"] = warnings + [f"Check: {x}" for x in result.pop("_check_issues", [])]
    return result


# ---------------------------------------------------------------------------
# Card prompt building, in-depth passes and validation
# ---------------------------------------------------------------------------
CARD_TEXT_FIELDS = ("name", "description", "personality", "scenario", "first_mes", "mes_example", "creator_notes",
                    "system_prompt", "post_history_instructions", "character_note", "depth_prompt")
PROFILE_TEXT_FIELDS = ["sex", "species", "ethnicity", "race", "job_occupation", "gender", "sexual_attraction",
                       "pronouns", "relationship_to_user", "relationship_status", "backstory", "height", "weight",
                       "age", "story_point", "with_strangers", "with_close"]
PROFILE_LIST_FIELDS = ["appearance", "non_human_appearance", "personal_parts", "clothing", "accessories", "speech",
                       "personality_traits", "kinks", "likes", "dislikes", "loves", "hates", "motivations", "flaws",
                       "mannerisms", "relationships"]
SEXUAL_FIELDS_LIST = ["kinks", "personal_parts"]
SEXUAL_FIELDS_TEXT = ["sexual_attraction"]

TOKEN_TARGETS = {   # permanent tokens: description + personality + scenario
    "small": (600, "SMALL-MODEL CARD: description <= 250 tokens, personality <= 100, scenario <= 80. Short, plain sentences."),
    "lean": (800, "LEAN CARD: description <= 400 tokens, personality <= 150, scenario <= 100."),
    "standard": (1200, "STANDARD CARD: description 400-700 tokens, personality <= 250, scenario <= 150."),
    "rich": (1800, "RICH CARD: description up to 1100 tokens, personality <= 350, scenario <= 200."),
}

BIBLE_SYSTEM = """You build a CHARACTER BIBLE from source data, as the fact base for a roleplay character card.
Return ONLY valid JSON, no fences:
{"name": "", "aliases": [], "story_point": "which version / moment of the character this describes",
 "age": "", "species": "", "identity": "who they are in 2-3 sentences",
 "appearance": [], "outfit": [], "personality": ["behavioural statements, not adjectives"],
 "voice": {"quotes": ["verbatim lines from the source, max 25 words"], "patterns": ["how they talk"]},
 "relationships": [{"with": "", "relation": ""}], "motivations": [], "fears_and_flaws": [],
 "key_history": ["events that shaped them, oldest first"], "abilities": [],
 "changes_in_this_story": ["facts where this source differs from the original canon"],
 "uncertain": ["things the source does not settle"]}
Rules: only facts the source supports; prefer specific details; quotes copied exactly; leave fields empty rather than guess."""

CHECK_SYSTEM = """You check a SillyTavern character card against its character bible. Return ONLY valid JSON:
{"fixes": {"<field>": "<corrected value>"}, "issues": ["short description of each problem you fixed or could not fix"]}
Fix ONLY: facts that contradict the bible; invented facts the bible does not support; any text that speaks or acts
for {{user}}; a missing or empty required field (description, personality, scenario, first_mes, mes_example);
a mes_example not in the <START> block format; fields far over their size target; structured_profile.with_strangers
and with_close saying the same thing when the bible shows the character acts differently with strangers and friends.
Field names: description, personality, scenario, first_mes, mes_example, alternate_greetings (list), character_note,
tags (list), or structured_profile.<subfield>. Leave everything else out. If nothing is wrong, return {"fixes": {}, "issues": []}."""


def _progress(options, msg):
    cb = options.get("progress") if isinstance(options, dict) else None
    if callable(cb):
        try:
            cb(msg)
        except Exception:
            pass


def _is_fic_source(source):
    return (source or {}).get("wiki_base") == "text-studio"


def _fic_note(source):
    if not _is_fic_source(source):
        return ""
    return ("\n\nTHIS SOURCE IS A FAN FICTION, not the original canon. Where it differs from canon, the fan fiction "
            "wins. Facts marked 'changed by this story', 'original to this story' or listed as story events are the "
            "truth for this character. Use canon only to fill gaps the fan fiction leaves open.")


def _story_point_note(options):
    sp = str(options.get("story_point") or "").strip()
    return f"\n\nSTORY POINT: describe the character as of: {sp}. Ignore facts from later in their story." if sp else ""


GREETING_POV = {
    "third": "third person: {{char}} as he/she/they, {{user}} by name ({{user}})",
    "second": "second person for {{user}} (\"you\"), with {{char}} in third person",
    "first": "first person as {{char}} (\"I\"), with {{user}} as \"you\"",
}
GREETING_TENSE = {"past": "past tense", "present": "present tense"}
GREETING_LENGTH = {
    "short": "one short paragraph, about 50-100 words",
    "medium": "2-3 paragraphs, about 150-250 words",
    "long": "4-6 paragraphs, about 300-450 words",
}


def greeting_style(style):
    """{'pov','tense','length'} (any may be empty = let the model choose) -> one rule line, or ''."""
    if isinstance(style, str):
        try:
            style = json.loads(style)
        except (json.JSONDecodeError, ValueError):
            style = {}
    style = style if isinstance(style, dict) else {}
    bits = [GREETING_POV.get(style.get("pov") or ""), GREETING_TENSE.get(style.get("tense") or ""),
            GREETING_LENGTH.get(style.get("length") or "")]
    bits = [b for b in bits if b]
    return ("Write it in " + "; ".join(bits) + ". Never write {{user}}'s actions or words.") if bits else ""


def card_system_prompt(source, options):
    """The system prompt for a full card, assembled from the options."""
    options = options or {}
    fic = _is_fic_source(source)
    target_key = options.get("token_target") if options.get("token_target") in TOKEN_TARGETS else "standard"
    style = options.get("style") or "prose"
    task = ("You are converting NOTES FROM A FAN FICTION into a SillyTavern V2 character card." if fic else
            "You are converting scraped wiki data into a SillyTavern V2 character card.")
    canon_rule = ("- The fan fiction is the truth: keep its changes to canon. Use canon only where the notes are silent."
                  if fic else "- Stay canon-consistent. Rewrite for roleplay, not wiki style.")
    extra = []
    sp = str(options.get("story_point") or "").strip()
    if sp:
        extra.append(f"- STORY POINT: write the character as of {sp}. Age, look, relationships and knowledge must match "
                     f"that moment; ignore later events. Put it in structured_profile.story_point.")
    role = str(options.get("user_role") or "").strip()
    if role:
        extra.append(f"- {{{{user}}}} IS: {role}. Build scenario, relationship_to_user and first_mes around that.")
    if options.get("lore_aware"):
        extra.append("- A LOREBOOK with the world, places, factions and other characters is attached to this card. "
                     "Keep world facts OUT of description and scenario; describe only this character and their "
                     "relationship to the world in a sentence or two. Keep the card lean.")
    extra.append("- SIZE: " + TOKEN_TARGETS[target_key][1])
    gs = greeting_style(options.get("greeting_style"))
    if gs:
        extra.append("- FIRST MESSAGE AND GREETINGS (this overrides any length given for them): " + gs.replace("Write it", "Write each")
                     + " Example messages use the same point of view and tense.")
    if style == "plist":
        extra.append("- STYLE: write description as a PList: [Name's persona: trait, trait; Name's appearance: ...; "
                     "Name's likes: ...] (square brackets, semicolons between categories). Write mes_example in "
                     "Ali:Chat style: each block shows {{char}} answering, revealing traits through action and dialogue.")
    else:
        extra.append("- STYLE: prose. Description in short paragraphs (appearance, personality, mannerisms).")
    extra_txt = "\n".join(extra)
    return f"""{CHARACTER_CARD_DEFINITION}

---

{task}
Return ONLY valid JSON. No markdown fences. No extra commentary.

RULES:
- Do not invent facts not present in the source.
{canon_rule}
- Make personality behavioral - not a list of adjectives.
- first_mes must be short, natural, and in character. If a Quotes section
  exists in the source, use a quote to anchor the character's voice.
- Do not write actions or dialogue for {{{{user}}}}.
- alternate_greetings: 2-3 extra openings in different situations (same voice, same rules as first_mes).
- character_note: 1-3 short sentences (max ~60 tokens) restating the traits and speech habits that matter most.
  SillyTavern injects it deep in the chat to keep the character consistent in long roleplays.
- mes_example must contain 3-6 examples. Exact format as a JSON string:
  "<START>\\n{{{{char}}}}: line one\\n\\n<START>\\n{{{{char}}}}: line two"
  Critical: TWO newlines (\\n\\n) between each block. Never place <START>
  immediately after dialogue on the same line as the previous entry.
  If a Quotes section exists, use those quotes as the basis for examples.
- scenario: roleplay-ready setup grounded in the source. Describe the situation
  and where the interaction begins. Do not write a full story scene.
- structured_profile: fill using three-level priority chain:
  Level 1 — infobox fields and named sections (Appearance, Personality, Quotes,
    Likes/Dislikes). Use these directly.
  Level 2 — structured source sections (history, biography, raw_sections).
    Infer from stated preferences, behavioral descriptions, dialogue.
  Level 3 — story_sections and uncategorized_sections. Read as raw narrative.
    Infer only what the text genuinely supports. Never fabricate.
  species = what kind of being they are (human, elf, android, demon...).
  motivations / flaws / mannerisms: short specific phrases. relationships: "Name - relation" phrases.
  with_strangers / with_close: 1-2 sentences each on how they act with strangers versus with people they trust
  (guarded vs. teasing, formal vs. blunt...). They should differ unless the source says the character is the same with
  everyone.
  Never leave likes/dislikes/loves/hates all blank if ANY behavioral content
  exists in the source. relationship_to_user: fill with a source-consistent
  default (or from the {{{{user}}}} role given below). List fields: short specific phrases. Leave blank only if no basis
  exists at any level.
- If the character is under 18, or reads as a minor: leave kinks, personal_parts and sexual_attraction empty and put
  no sexual or romantic-sexual content anywhere in the card.
{extra_txt}

Return this exact JSON shape:
{{
  "name": "",
  "structured_profile": {{
    "sex": "", "species": "", "ethnicity": "", "race": "", "job_occupation": "",
    "gender": "", "sexual_attraction": "", "pronouns": "",
    "appearance": [], "non_human_appearance": [], "personal_parts": [],
    "clothing": [], "accessories": [],
    "relationship_to_user": "", "relationship_status": "",
    "backstory": "", "speech": [], "personality_traits": [],
    "kinks": [], "likes": [], "dislikes": [],
    "loves": [], "hates": [],
    "motivations": [], "flaws": [], "mannerisms": [], "relationships": [],
    "with_strangers": "", "with_close": "",
    "height": "", "weight": "", "age": "", "story_point": ""
  }},
  "description": "",
  "personality": "",
  "scenario": "",
  "first_mes": "",
  "alternate_greetings": ["", ""],
  "character_note": "",
  "mes_example": "<START>\\n{{{{char}}}}: ...\\n\\n<START>\\n{{{{char}}}}: ...\\n\\n<START>\\n{{{{char}}}}: ...",
  "tags": []
}}"""


def apply_card_fixes(card, fixes):
    n = 0
    for k, v in (fixes or {}).items():
        if not isinstance(k, str):
            continue
        if k.startswith("structured_profile."):
            sub = k.split(".", 1)[1]
            if sub in PROFILE_TEXT_FIELDS or sub in PROFILE_LIST_FIELDS:
                card.setdefault("structured_profile", {})[sub] = v
                n += 1
        elif k in ("description", "personality", "scenario", "first_mes", "mes_example", "alternate_greetings",
                   "character_note", "tags"):
            card[k] = v
            n += 1
    return n


_MINOR_RE = re.compile(r"\b(child|kid|toddler|teen|teenage|teenager|minor|adolescent|schoolboy|schoolgirl|"
                       r"high[- ]school|middle[- ]school|preteen|underage)\b", re.I)


def _reads_as_minor(age_text):
    t = str(age_text or "")
    nums = [int(n) for n in re.findall(r"\b(\d{1,3})\b", t) if 0 < int(n) < 130]
    if nums:
        return min(nums) < 18 and not any(n >= 18 for n in nums)
    return bool(_MINOR_RE.search(t))


def estimate_tokens(text):
    return max(0, round(len(str(text or "")) / 4))


def validate_card(card, options=None):
    """Repair what code can repair and list what needs a human look. Returns (card, warnings)."""
    options = options or {}
    warnings = []
    # text fields stay text even when a model sends a list or an object
    for k in CARD_TEXT_FIELDS:
        if k in card and not isinstance(card[k], str):
            card[k] = text_of(card[k], "\n")
    if isinstance(card.get("alternate_greetings"), list):
        card["alternate_greetings"] = list_of(card["alternate_greetings"], split=False)
    tidy_card(card)
    sp = card.get("structured_profile") or {}
    if isinstance(sp, str):
        try:
            sp = json.loads(sp)
        except (json.JSONDecodeError, ValueError):
            sp = {}
    if not isinstance(sp, dict):
        sp = {}
    for f in PROFILE_LIST_FIELDS:
        if f in sp:
            sp[f] = list_of(sp[f])
    for f in PROFILE_TEXT_FIELDS:
        if f in sp and not isinstance(sp[f], str):
            sp[f] = text_of(sp[f], ", ")
    if not sp.get("species") and sp.get("ethnicity"):
        sp["species"] = sp["ethnicity"]          # older sources keep species in 'ethnicity'
    card["structured_profile"] = sp

    # example messages: <START> on its own line, a blank line between blocks
    mes = str(card.get("mes_example") or "").replace("\r\n", "\n")
    if mes:
        fixed = re.sub(r"\s*<START>\s*", "\n\n<START>\n", mes).strip()
        if fixed != mes.strip():
            warnings.append("Example messages: fixed the <START> block spacing.")
        mes = fixed
        if not mes.startswith("<START>"):
            mes = "<START>\n" + mes
        if re.search(r"(^|\n)\{\{user\}\}:", mes):
            warnings.append("Example messages contain {{user}} lines; the card should only show {{char}}.")
    card["mes_example"] = mes

    fm = str(card.get("first_mes") or "")
    if re.search(r"(^|\n)\s*\{\{user\}\}\s*:", fm) or re.search(r"\*\{\{user\}\}\s+\w+s\b", fm):
        warnings.append("First message seems to speak or act for {{user}}; check it.")
    if not fm.strip():
        warnings.append("First message is empty.")

    card["alternate_greetings"] = list_of(card.get("alternate_greetings"), split=False, limit=5)
    card["character_note"] = text_of(card.get("character_note") or card.get("depth_prompt"), "\n")

    tags, seen = [], set()
    for t in list_of(card.get("tags")):
        t = str(t).strip().lstrip("#").lower()
        if t and t not in seen:
            seen.add(t)
            tags.append(t)
    card["tags"] = tags
    if len(tags) < 10:
        warnings.append(f"Only {len(tags)} tags (aim for 10-20).")

    for f in ("description", "personality", "scenario"):
        if not str(card.get(f) or "").strip():
            warnings.append(f"{f.capitalize()} is empty.")

    if _reads_as_minor(sp.get("age")):
        cleared = [f for f in SEXUAL_FIELDS_LIST if sp.get(f)] + [f for f in SEXUAL_FIELDS_TEXT if sp.get(f)]
        for f in SEXUAL_FIELDS_LIST:
            sp[f] = []
        for f in SEXUAL_FIELDS_TEXT:
            sp[f] = ""
        if cleared:
            warnings.append("Character is under 18: sexual profile fields were left empty.")

    perm = sum(estimate_tokens(card.get(f)) for f in ("description", "personality", "scenario"))
    target_key = options.get("token_target") if options.get("token_target") in TOKEN_TARGETS else "standard"
    limit = TOKEN_TARGETS[target_key][0]
    if perm > limit * 1.25:
        warnings.append(f"Permanent tokens about {perm} (target ~{limit}). Consider trimming the description.")
    try:
        from prose_scan import card_text_warnings
        hits = card_text_warnings(card)
        if hits:
            warnings.append("Stock phrases worth rewriting: " + "; ".join(hits))
    except Exception:
        pass
    return card, warnings


# -------------------------------------------------------------------------------
# Single field regeneration
# -------------------------------------------------------------------------------

def regenerate_single_field(
    source: Dict[str, Any],
    card: Dict[str, Any],
    field_name: str,
    provider: str,
    model: str,
    custom_prompt: str = "",
    include_current_card: bool = True,
    include_source: bool = True,
    greeting_style_opt=None,
) -> Dict[str, Any]:
    templates = get_prompt_templates()
    config = load_runtime_config()
    use_config = config.get("use_templates", False)

    normalized = source.get("normalized", {})
    compact_source = {
        "title":              normalized.get("title", ""),
        "summary":            normalized.get("summary", ""),
        "franchise":          normalized.get("franchise", ""),
        "appearance_list":    normalized.get("appearance_list", [])[:12],
        "personality_traits": normalized.get("personality_traits", [])[:12],
        "abilities_list":     normalized.get("abilities_list", [])[:12],
        "history_list":       normalized.get("history_list", [])[:12],
        "normalized_infobox": normalized.get("normalized_infobox", {}),
    }
    source_json = json.dumps(compact_source, ensure_ascii=False, indent=2)

    structured_subfields = {
        "species", "story_point", "motivations", "flaws", "mannerisms", "relationships",
        "with_strangers", "with_close",
        "sex", "ethnicity", "race", "job_occupation", "gender",
        "sexual_attraction", "pronouns", "appearance", "non_human_appearance",
        "personal_parts", "clothing", "accessories", "relationship_to_user",
        "relationship_status", "backstory", "speech", "personality_traits",
        "kinks", "likes", "dislikes", "loves", "hates", "height", "weight", "age",
    }
    list_subfields = {
        "motivations", "flaws", "mannerisms", "relationships",
        "appearance", "non_human_appearance", "personal_parts", "clothing",
        "accessories", "speech", "personality_traits", "kinks",
        "likes", "dislikes", "loves", "hates",
    }

    # Trim the card to only what's relevant for this field — full card is too many tokens
    sp = card.get("structured_profile", {})
    if field_name in structured_subfields:
        # Structured field: only needs name + description + personality for context
        compact_card = {
            "name": card.get("name", ""),
            "description": card.get("description", "")[:500],
            "personality": card.get("personality", "")[:500],
            "structured_profile": sp,
        }
    elif field_name == "description":
        compact_card = {
            "name": card.get("name", ""),
            "personality": card.get("personality", "")[:400],
            "structured_profile": {k: sp.get(k) for k in
                ["appearance", "clothing", "accessories", "ethnicity", "race", "height", "age"] if sp.get(k)},
        }
    elif field_name == "personality":
        compact_card = {
            "name": card.get("name", ""),
            "description": card.get("description", "")[:400],
            "structured_profile": {k: sp.get(k) for k in
                ["personality_traits", "speech", "likes", "dislikes", "loves", "hates", "relationship_to_user"] if sp.get(k)},
        }
    elif field_name in ("first_mes", "mes_example"):
        compact_card = {
            "name": card.get("name", ""),
            "personality": card.get("personality", "")[:400],
            "scenario": card.get("scenario", "")[:300],
            "first_mes": card.get("first_mes", "") if field_name == "mes_example" else "",
        }
    elif field_name == "scenario":
        compact_card = {
            "name": card.get("name", ""),
            "description": card.get("description", "")[:400],
            "personality": card.get("personality", "")[:300],
        }
    else:
        compact_card = {
            "name": card.get("name", ""),
            "description": card.get("description", "")[:300],
            "personality": card.get("personality", "")[:300],
        }
    card_json = json.dumps(compact_card, ensure_ascii=False, indent=2)

    # System: definitions + task framing
    canon_rule = ("The source is a FAN FICTION: keep its changes to canon; use canon only where it is silent."
                  if _is_fic_source(source) else "Stay canon-consistent.")
    system = f"""{CHARACTER_CARD_DEFINITION}

---

You are rewriting exactly ONE field of a SillyTavern character card.
Return ONLY valid JSON in the exact shape specified. No markdown fences.
{canon_rule} Do not invent facts beyond the source or current card.
Do not write actions or dialogue for {{{{user}}}}.
If the character is under 18 or reads as a minor, write no sexual content and leave kinks, personal_parts and sexual_attraction empty."""

    # User: build the task
    template_text = templates.get("field_regeneration_template", "").strip()
    custom_instruction = custom_prompt.strip()

    if use_config and template_text:
        try:
            user = template_text.format(
                field_name=field_name,
                source_json=source_json,
                card_json=card_json,
                custom_prompt=custom_instruction,
            )
        except Exception as e:
            _log_warn(f"Template error, falling back to default: {e}")
            user = None
    else:
        user = None

    if not user:
        parts = [f"Target field: {field_name}", ""]

        if field_name == "structured_profile":
            parts += [
                'Return this shape exactly:',
                '{"structured_profile": {"sex":"","ethnicity":"","race":"","job_occupation":"","gender":"","sexual_attraction":"","pronouns":"","appearance":[],"non_human_appearance":[],"personal_parts":[],"clothing":[],"accessories":[],"relationship_to_user":"","relationship_status":"","backstory":"","speech":[],"personality_traits":[],"kinks":[],"likes":[],"dislikes":[],"loves":[],"hates":[],"height":"","weight":"","age":"","species":"","story_point":"","motivations":[],"flaws":[],"mannerisms":[],"relationships":[],"with_strangers":"","with_close":""}}',
            ]
        elif field_name in structured_subfields:
            if field_name in list_subfields:
                parts += [
                    "Return this shape exactly:",
                    f'{{"structured_profile": {{"{field_name}": []}}}}',
                    f"Rules: short specific phrases only. Leave empty if no source basis.",
                ]
            else:
                parts += [
                    "Return this shape exactly:",
                    f'{{"structured_profile": {{"{field_name}": ""}}}}',
                    f"Rules: fill only if source directly states or strongly implies it.",
                ]
        elif field_name == "tags":
            parts += [
                "Return this shape: {\"tags\": []}",
                "Generate at least 10 tags from the source. Include: franchise/series name, "
                "character type, personality traits, setting, abilities, genre, physical traits, "
                "relationship role. Use lowercase, no hashtags. Be specific. Aim for 10-20 tags.",
            ]
        elif field_name == "scenario":
            parts += [
                'Return this shape: {"scenario": ""}',
                "Rules: roleplay-ready setup grounded in canon. Do not write {{user}} lines.",
            ]
        elif field_name == "mes_example":
            parts += [
                'Return this shape: {"mes_example": "<START>\\n{{char}}: ...\\n\\n<START>\\n{{char}}: ..."}',
                "Rules: 3-6 examples. Format: <START>\\n{{char}}: line\\n\\n<START>\\n{{char}}: line — TWO newlines (\\n\\n) between blocks. Never run <START> onto same line as previous dialogue. Show different moods. No {{user}} lines.",
            ] + ([greeting_style(greeting_style_opt).replace("Write it in", "Narration uses").split(" Never")[0]]
                 if greeting_style(greeting_style_opt) else [])
        elif field_name == "first_mes":
            parts += ['Return this shape: {"first_mes": ""}',
                      "Rules: the opening message of the roleplay, in character, setting the scene from the scenario. "
                      + (greeting_style(greeting_style_opt) or "Keep it natural and roleplay-ready. Never write {{user}}'s actions or words.")]
        elif field_name == "alternate_greetings":
            parts += ['Return this shape: {"alternate_greetings": ["", ""]}',
                      "Rules: 2-3 extra openings in different situations, same voice as first_mes. "
                      + (greeting_style(greeting_style_opt) or "Never write {{user}}'s actions or words.")]
        elif field_name == "depth_prompt":
            parts += ['Return this shape: {"depth_prompt": ""}',
                      "Rules: the Character's Note SillyTavern injects deep in the chat: 1-3 short sentences (max ~60 tokens) "
                      "restating the traits and speech habits that matter most. Third person, present tense."]
        elif field_name == "system_prompt":
            parts += ['Return this shape: {"system_prompt": ""}',
                      "Rules: short roleplay instructions for this character (2-5 sentences). Never control {{user}}."]
        else:
            parts += [f'Return this shape: {{"{field_name}": ""}}']

        if custom_instruction:
            parts += ["", f"Additional instruction: {custom_instruction}"]

        if include_source:
            parts += ["", "SOURCE DATA:", source_json]

        if include_current_card:
            parts += ["", "CURRENT CARD:", card_json]

        user = "\n".join(parts)

    # plain prose is accepted as the answer for one field; models also often skip the wrapper object
    result = request_text(provider, model, user, system, field_name)
    sp = result.get("structured_profile")
    if isinstance(sp, str):
        try:
            sp = json.loads(sp)
        except (json.JSONDecodeError, ValueError):
            sp = None
    if not isinstance(sp, dict):
        sp = None

    if field_name == "structured_profile":
        if sp is None:                      # the profile itself, without the wrapper
            sp = {k: v for k, v in result.items() if k in structured_subfields}
        if not sp:
            raise ValueError("The model returned no profile. Try again or pick another model.")
        return {"structured_profile": sp}

    if field_name in structured_subfields:
        val = (sp or {}).get(field_name, result.get(field_name))
        if val is None or not text_of(val):
            raise ValueError(f"The model returned nothing for {field_name}. Try again or pick another model.")
        val = list_of(val) if field_name in list_subfields else text_of(val, ", ")
        return {"structured_profile": {field_name: val}}

    if field_name == "tags":
        tags = list_of(result.get("tags"))
        if not tags:
            raise ValueError("The model returned no tags. Try again or pick another model.")
        return {"tags": tags}

    if field_name == "alternate_greetings":
        greets = [tidy_text(g, card.get("name") or "") for g in list_of(result.get(field_name), split=False)]
        if not greets:
            raise ValueError("The model returned no greetings. Try again or pick another model.")
        return {field_name: greets}

    value = tidy_text(text_of(result.get(field_name), "\n"), (card.get("name") or "") if field_name == "first_mes" else "")
    if not value:
        raise ValueError(f"The model returned nothing for {field_name}. Try again or pick another model.")
    return {field_name: value}


# -------------------------------------------------------------------------------
# Lore entry generation  (unified - used by single, multi, and crawl paths)
# -------------------------------------------------------------------------------

def generate_lore_entry(
    source: Dict[str, Any],
    provider: str,
    model: str,
    purpose: str = "Create lorebook entries from this wiki page.",
    criteria: str = "The page must be a detailed article about a specific subject, not a list or category page.",
    extraction_notes: str = "Focus on relationships, affiliations, and worldbuilding context. Ignore gameplay mechanics.",
    deep: bool = False,
) -> Dict[str, Any]:
    """
    Generate one or more lore entries from a source page.

    Returns a dict:
      {
        "valid": bool,
        "reason": str | None,       # why skipped if not valid
        "entries": [ { title, entry_type, keywords, summary, content }, ... ]
      }

    The valid/reason pattern lets the model
    explicitly skip bad pages rather than generating garbage entries.
    """
    if deep:
        # Multi-pass extraction (inventory -> gleaning -> name check -> details -> events).
        # Slower (several calls per ~4k chars) but does not stall at a handful of entries.
        from lore_extract import source_to_text
        from text_module import deep_entries_from_text
        page_text = source_to_text(source)
        if len(page_text.strip()) < 200:
            return {"valid": False, "reason": "Not enough text on the page for deep extraction.", "entries": []}
        return {"valid": True, "reason": None,
                "entries": deep_entries_from_text(page_text, provider, model)}

    # Build source content - prefer structured normalized data, fall back to raw text
    normalized = source.get("normalized", {})
    title = source.get("title") or normalized.get("title") or source.get("url", "")

    # Include raw abilities/attacks text even when structured data exists
    # because ability section names vary widely ("Attacks", "Moveset", etc.)
    # and may land in uncategorized_sections rather than abilities_list
    raw_abilities = normalized.get("abilities", "").strip()
    # uncategorized_sections lives in normalized (from parse_page) for Fandom pages
    uncategorized = normalized.get("uncategorized_sections") or source.get("uncategorized_sections", {})
    # Pull any section that looks ability-related from uncategorized
    ability_keywords = {"attack", "moveset", "move", "skill", "power", "ability", "technique", "magic", "spell", "art"}
    extra_abilities = {}
    for section_name, paragraphs in (uncategorized.items() if isinstance(uncategorized, dict) else {}.items()):
        if any(kw in section_name.lower() for kw in ability_keywords):
            extra_abilities[section_name] = paragraphs[:5]

    structured = {
        "title":              normalized.get("title", ""),
        "summary":            normalized.get("summary", ""),
        "franchise":          normalized.get("franchise", ""),
        "normalized_infobox": normalized.get("normalized_infobox", {}),
        "personality_traits": normalized.get("personality_traits", [])[:10],
        "abilities_list":     normalized.get("abilities_list", [])[:15],
        "history_list":       normalized.get("history_list", [])[:8],
        "relationships":      normalized.get("relationships", [])[:8],
    }
    # Always append raw abilities text and extra sections if present
    if raw_abilities:
        structured["abilities_raw"] = raw_abilities[:3000]
    if extra_abilities:
        structured["extra_ability_sections"] = extra_abilities

    has_structured = any(                   # .get: a sparse page has no abilities_raw / extra sections key at all
        structured.get(k) for k in ["summary", "normalized_infobox", "personality_traits", "history_list",
                                  "abilities_list", "abilities_raw", "extra_ability_sections"]
    )
    if has_structured:
        content_block = json.dumps(structured, ensure_ascii=False, indent=2)
    else:
        raw = source.get("raw_text") or source.get("content") or ""
        content_block = raw[:8000] if raw else json.dumps(structured, ensure_ascii=False)

    # System: lorebook definition + task framing
    system = f"""{LOREBOOK_DEFINITION}

---

You are generating SillyTavern lorebook entries from a wiki page.
Return ONLY valid JSON. No markdown fences.

TASK:
Purpose: {purpose}
Criteria: {criteria}
Extraction notes: {extraction_notes}

STEP 1 - VALIDATE:
Check if this page meets the criteria above.
- If NOT valid: set "valid": false, explain in "reason", set "entries": []
- If valid: set "valid": true, "reason": null, fill "entries"

STEP 2 - GENERATE (only if valid):
Extract EVERY distinct named entity from the source as its own entry.
Aim for 10-20 entries per page minimum. Rich pages should yield more.

Work through ALL source sections in this order:
1. Named sections (Personality, Appearance, Abilities, Quotes, Background, History)
2. Structured sections (history_list, raw_sections, relationships)
3. story_sections and uncategorized_sections — scan EVERY paragraph for named
   characters, locations, factions, events, and abilities. Each one is an entry.

Extract entries for:
- Every named character mentioned → Layer 3 (entry_type: "character")
- Every named faction, organization, army, school, institution → Layer 2 (entry_type: "faction")
- Every named city, town, region, kingdom, realm → Layer 4 (entry_type: "place")
- Every named building, landmark, district, facility → Layer 4 (entry_type: "place")
- Every named ability, technique, power, spell → Layer 4 (entry_type: "ability")
- Every named item, weapon, artifact → Layer 4 (entry_type: "item")
- Every named event, battle, incident → Layer 4 (entry_type: "event")
- Core world rules or power systems → Layer 1 (entry_type: "concept")
- Key relationships that define the character → Layer 4 (entry_type: "concept")

Additional rules:
- If abilities_list or extra_ability_sections exist: one entry per named ability.
- If a Quotes section exists: use quotes in the character entry to anchor voice.
- If infobox has Likes/Dislikes: include them in the character entry content.
- If episode or season summaries exist in uncategorized_sections: mine every
  paragraph — named characters, locations, and events each get their own entry.
- Do not group multiple entities into one entry.
- Layer 2 faction entries must name every key member in their content.
- Layer 4 location entries must name NPCs and items present within them.

Return this exact JSON shape:
{{
  "valid": true,
  "reason": null,
  "entries": [
    {{
      "title": "",
      "entry_type": "character|ability|item|faction|place|event|concept",
      "keywords": [],
      "summary": "",
      "content": ""
    }}
  ]
}}"""

    user = f"SOURCE URL: {source.get('url', '')}\n\nSOURCE CONTENT:\n{content_block}"

    result = _request(provider, model, user, system=system)

    # Normalise the response: the wrapper may be missing, entries may be one object, fields may be the wrong type
    raw = result.get("entries")
    if raw is None and "title" in result:
        raw = [result]
    if isinstance(raw, dict):
        raw = [raw]
    if not isinstance(raw, list):
        if "valid" in result and _truthy(result.get("valid")) is False:
            return {"valid": False, "reason": text_of(result.get("reason")) or None, "entries": []}
        return {"valid": False, "reason": "Model returned unexpected structure", "entries": []}
    entries = []
    for entry in raw:
        if not isinstance(entry, dict) or not text_of(entry.get("title")):
            continue
        entry = dict(entry)
        entry["title"] = text_of(entry["title"])
        entry["keywords"] = list_of(entry.get("keywords"))
        for k in ("entry_type", "summary", "content"):
            if k in entry and not isinstance(entry[k], str):
                entry[k] = text_of(entry[k], "\n")
        for k in ("summary", "content"):
            entry[k] = tidy_text(entry.get(k) or "")
        entries.append(entry)
    valid = _truthy(result.get("valid", True))
    return {
        "valid":   bool(entries) if valid is None else valid,
        "reason":  text_of(result.get("reason")) or None,
        "entries": entries,
    }


_CJK = re.compile(r"[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af\uff00-\uffef]")
_LOOSE_HTML = re.compile(r"</?(?:p|div|span)(?:\s[^<>]*)?>", re.I)


def tidy_text(value, name=""):
    """Clean up model text before it is stored: straight quotes, ... for the ellipsis, no stray <p>/<div>/<span>
    or <br>, no doubled spaces, at most one blank line, no code fence around the whole thing, and (with name) no
    'Name:' in front of a greeting. Leaves XML-style tags like <personality> alone (some cards use them on purpose).
    CJK text keeps its own quotes. Not used on text the user typed."""
    if not isinstance(value, str) or not value:
        return value
    s = value.replace("\r\n", "\n").replace("\r", "\n").strip()
    fence = re.fullmatch(r"```[\w-]*\n([\s\S]*?)\n?```", s)
    if fence:
        s = fence.group(1).strip()
    s = re.sub(r"<br\s*/?>", "\n", s, flags=re.I)
    s = _LOOSE_HTML.sub("", s)
    if not _CJK.search(s):
        s = (s.replace("\u201c", '"').replace("\u201d", '"').replace("\u201e", '"')
              .replace("\u2018", "'").replace("\u2019", "'").replace("\u2026", "..."))
    s = re.sub(r"(?<=\S)[ \t]{2,}(?=\S)", " ", s)
    s = re.sub(r"[ \t]+\n", "\n", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    if name:
        s = re.sub(r"^(?:\{\{char\}\}|" + re.escape(name.strip()) + r")\s*:\s*", "", s, flags=re.I) if name.strip() else s
    return s.strip()


def clean_card_payload(card):
    """Card JSON from the browser (or another client) with every field in the shape the database and exports expect."""
    out = dict(card)
    for k in CARD_TEXT_FIELDS + ("depth_prompt", "post_history", "system_prompt", "creator_notes"):
        if k in out and out[k] is not None and not isinstance(out[k], str):
            out[k] = text_of(out[k], "\n")
    if "tags" in out:
        out["tags"] = list_of(out["tags"])
    if "alternate_greetings" in out:
        out["alternate_greetings"] = list_of(out["alternate_greetings"], split=False)
    if "structured_profile" in out:
        sp = out["structured_profile"]
        if isinstance(sp, str):
            try:
                sp = json.loads(sp)
            except ValueError:
                sp = {}
        sp = dict(sp) if isinstance(sp, dict) else {}
        for f in PROFILE_LIST_FIELDS:
            if f in sp and not isinstance(sp[f], list):
                sp[f] = list_of(sp[f])
        out["structured_profile"] = sp
    return out


GREETING_FIELDS = ("first_mes", "alternate_greetings")


def tidy_card(card):
    """tidy_text on every generated text field of a card (and each alternate greeting), in place."""
    name = str(card.get("name") or "")
    for k in CARD_TEXT_FIELDS:
        if isinstance(card.get(k), str) and k != "name":
            card[k] = tidy_text(card[k], name if k == "first_mes" else "")
    if isinstance(card.get("alternate_greetings"), list):
        card["alternate_greetings"] = [tidy_text(g, name) if isinstance(g, str) else g for g in card["alternate_greetings"]]
    return card


def _truthy(v):
    """true / "true" / "yes" / 1 -> True, false / "false" / "no" / 0 -> False, else None."""
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    t = str(v or "").strip().lower()
    return True if t in ("true", "yes", "y", "1") else False if t in ("false", "no", "n", "0") else None
